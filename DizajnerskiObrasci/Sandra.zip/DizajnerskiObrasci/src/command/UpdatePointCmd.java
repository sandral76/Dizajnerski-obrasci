package command;

import mvc.Point;

public class UpdatePointCmd implements Command {
	private Point oldState;
	private Point newState;
	private Point original=new Point(); //kad menjamo sa starog na novog stanje, i ako hocemo da vratimo posle na prethodno, mi smo staro preklopili sa novim, tako da moramo prvobitnu vrednsot negde cuvati

	public UpdatePointCmd(Point oldState, Point newState) {
		this.oldState = oldState;
		this.newState = newState;
	}

	@Override
	public void execute() {
		original.setX(oldState.getX());
		original.setY(oldState.getY());
		original.setColor(oldState.getColor());
		
		oldState.setX(newState.getX());
		oldState.setY(newState.getY());
		oldState.setColor(newState.getColor());
	}

	@Override
	public void unexecute() {
		oldState.setX(original.getX());
		oldState.setY(original.getY());
		oldState.setColor(original.getColor());
        
}
}
