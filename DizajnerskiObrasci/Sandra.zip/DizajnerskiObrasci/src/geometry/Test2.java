package geometry;

public class Test2 {
	public static void main(String[] args) {
		Point p1=new Point();
		p1.setX(10);
		p1.setY(20);
		p1.setSelected(true);
		
	}
}
