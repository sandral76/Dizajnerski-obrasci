package geometry;

public interface Moveable {
   //ne mozemo naprzviti instancu interfejsa
	//potpuno apstrktna klasa
	//svaka metoda u okviru inrtfejsa je apstrkata
	
	
	public abstract void moveBy(int byX, int byY);
	//moze i bez public abstract
	
	
}
