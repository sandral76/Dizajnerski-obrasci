package adapter;

public class Plane implements Vehicle {

	@Override
	public void goFaster() {
		System.out.println("Plane is moving faster...");
	}

}
