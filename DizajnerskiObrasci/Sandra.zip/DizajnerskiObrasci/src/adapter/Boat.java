package adapter;

public class Boat {
	
	public void rowFaster() {
		System.out.println("Boat is moving faster...");
	}

}
