package adapter;

public class Train implements Vehicle {

	@Override
	public void goFaster() {
		System.out.println("Train is moving faster...");
	}

}
