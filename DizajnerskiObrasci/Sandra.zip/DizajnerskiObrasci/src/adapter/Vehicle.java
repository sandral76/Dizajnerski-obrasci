package adapter;

public interface Vehicle {
	
	void goFaster();
	

}
