package adapter;

public class Car implements Vehicle{

	@Override
	public void goFaster() {
		System.out.println("Car is moving faster..");
		
	}

}
