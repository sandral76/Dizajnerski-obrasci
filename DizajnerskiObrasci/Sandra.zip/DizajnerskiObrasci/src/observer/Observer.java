package observer;

public interface Observer {
	void update(double bitcoinPrice,double ethercoinPrice);

}
